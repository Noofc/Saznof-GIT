# Permissions Manager Module Initialization
